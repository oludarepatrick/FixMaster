$('.carousel').flickity({
    imagesLoaded: true, 
    wrapAround:true, 
    adaptiveHeight:true, 
    autoPlay:true,
});