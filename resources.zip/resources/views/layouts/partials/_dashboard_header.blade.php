<div class="content-header justify-content-center">
  {{-- <img src="{{ asset('assets/images/home-fix-logo.png') }}" alt="FixMaster Logo" height="160"> --}}
  {{-- <img src="{{ asset('assets/images/home-fix-logo-colored.png') }}" alt="FixMaster Logo" height="120"> --}}

  <img src="{{ asset('assets/images/home-fix-logo-colored.png') }}" height="65" alt="FixMaster Logo">

  {{-- <ul class="nav justify-content-center mt-1 float-center">
    <li class="nav-item"><h3 class="font-weight-bold">Fix<span style="color: #E97D1F;">Master</span></h3></li>
  </ul> --}}
</div><!-- content-header -->
